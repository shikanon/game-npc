# coding:utf-8
import requests
import asyncio
import websockets

def test_ask():
    url = "http://127.0.0.1:8000/ask"
    data = {
        "question": "我的账号有问题需要立刻帮我转人工", 
        "history_messages": [{
                "Human":"我的充值金额出现了问题，我充值了50块却只显示10块钱，快帮我看看"
            },
            {
                "AI":"好的，请问您方便提供下您的账号和订单号吗？"
            }]}
    response = requests.post(url, json=data)
    print(response.json())

    url = "http://127.0.0.1:8000/debug-ask"
    data = {"question": "使用 es-knn 作为向量数据库",
            "history_messages": []}
    response = requests.post(url, json=data)
    print(response.json())

def test_upload_file():
    url = "http://127.0.0.1:8000/uploadfile/"
    files = {'file': open('Readme.md', 'rb')}
    response = requests.post(url, files=files)
    print(response.json())

def test_save_faq():
    url = "http://127.0.0.1:8000/save-faq/"
    faq_id = "345"
    data = {
        "faq_id": faq_id,
        "question": "大模型的评测体系有哪些",
        "answer": """360评测 - 横向进行跨学科、跨能力维度的评测，用于快速衡量模型是否具有广泛的世界知识和各类问题解决能力。
    基础能力评测 - 为更专业解决某种场景的问题，模型需要在某些类别中体现更加突出的能力。因此方舟还提供不同侧重的，基于能力维度的模型评测选项。
    语言创作 - 理解与生成文本的能力，与人类语言考试的读、写对应
    推理数学 - 逻辑推理与数学计算，及延伸的对复杂规则的学习能力
    知识能力 - 记忆与理解各行各业知识，如常识、生活、社会文化等""",
        "faq_type": "knowledge",
    }
    response = requests.post(url, json=data)
    print(response.json())

    response = requests.delete(f"http://127.0.0.1:8000/delete-faq-by-id/{faq_id}")
    assert response.json() == {"status": "success"}


def test_load_template():
    url = "http://127.0.0.1:8000/load-template/"
    with open("gamenpc/template/game-customer-service.template","r",encoding="utf-8") as fr:
        templ = fr.read()
    data = {
        "template": templ,
        "template_id": 1,
    }
    requests.post(url, json=data)
    url = "http://127.0.0.1:8000/ask"
    data = {
        "question": "中国在哪里", 
        "history_messages": []}
    response = requests.post(url, json=data)
    print(response.json())
    url = "http://127.0.0.1:8000/ask"
    data = {
        "question": "这个游戏怎么充值", 
        "history_messages": []}
    response = requests.post(url, json=data)
    print(response.json())

async def test_websocket_chatbot():
    # connect to the websocket
    async with websockets.connect('ws://127.0.0.1:8000/ws-chatbot') as websocket:
        # Sending a sample message to assert against response.
        chat_message = '你好，我需要帮助'
        await websocket.send(chat_message)
        # Receiving response from server.
        while True:
            response = await websocket.recv()
            print(response)
            if response == "/n":
                break

if __name__ == "__main__":
    # asyncio.run(test_websocket_chatbot())
    test_load_template()